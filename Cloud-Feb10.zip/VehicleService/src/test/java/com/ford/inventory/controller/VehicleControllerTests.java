package com.ford.inventory.controller;

import static org.hamcrest.CoreMatchers.nullValue;
import static org.junit.Assert.assertEquals;

import org.hamcrest.Matcher;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.ford.inventory.domain.Vehicle;
import com.ford.inventory.service.ServiceException;
import com.ford.inventory.service.VehicleService;

@RunWith(SpringRunner.class)
@WebMvcTest(value=VehicleController.class, secure=false)
public class VehicleControllerTests {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(VehicleControllerTests.class);
	
	@Autowired
	private MockMvc mockMvc;
	
	private Vehicle vehicle = new Vehicle("VIN5", 2018, "Expo", "Auto", "LE", "Silver", "SUV", 35000d, "DLR1"); 
	private Vehicle InvalidVehicle = new Vehicle(null, 2018, "Expo", "Auto", "LE", "Silver", "SUV", 35000d, "DLR1");
	
	private String vehicleJson = "{" + 
			"\"vin\":\"VIN5\"," + 
			"\"year\":2018," + 
			"\"model\":\"Expo\"," + 
			"\"transmission\":\"Automatic\"," + 
			"\"trim\":\"LE\"," + 
			"\"color\":\"White\"," + 
			"\"type\":\"SUV\"," + 
			"\"price\":35000.0," + 
			"\"dealerCode\":\"DLR1\"" + 
			"}";
	
	private String InvalidVehicleJson = "{" + 
			"\"year\":2018," + 
			"\"model\":\"Expo\"," + 
			"\"transmission\":\"Automatic\"," + 
			"\"trim\":\"LE\"," + 
			"\"color\":\"White\"," + 
			"\"type\":\"SUV\"," + 
			"\"price\":35000.0," + 
			"\"dealerCode\":\"DLR1\"" + 
			"}";
	
	@MockBean
	private VehicleService vehicleService;
	
	@Before
	public void setup() {
		
		Mockito.when(vehicleService.create(Mockito.any(Vehicle.class))).thenReturn("VIN5");
		
		
		
	}
	
	@Test
	public void givenValidVehicleJson_whenCreateVehicle_thenReturnJson() throws Exception {
		String expectedJson = " {" + 
				"\"code\": \"VEHICLE_ADDED\"," + 
				"\"message\": \"Vehicle successfully added\"" + 
				"}";
		LOGGER.debug("inside givenValidVehicleJson_whenCreateVehicle_thenReturnJson");
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/api/vehicles/").accept(MediaType.APPLICATION_JSON)
				.content(vehicleJson).contentType(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		MockHttpServletResponse response = result.getResponse();
		//Mockito.verify(vehicleService).create(Matchers.refEq(vehicle));
		assertEquals("Expected code did not match", 200, response.getStatus());
		JSONAssert.assertEquals(expectedJson, response.getContentAsString(), false);
	}
	
	@Test
	public void givenInvalidVehicleJson_whenCreateVehicle_thenReturnJson() throws Exception {
		LOGGER.debug("VehicleControllerTests.givenInvalidVehicleJson_whenCreateVehicle_thenReturnJson()");
		String expectedJson = " {" + 
				"\"code\": \"INVALID_VEHICLE\"," + 
				"\"message\": \"Invalid Vehicle ID\"" + 
				"}";
		Mockito.when(
		vehicleService.create(org.mockito.Matchers.<Vehicle>argThat(
				org.hamcrest.CoreMatchers.allOf(
				org.hamcrest.Matchers.<Vehicle>
				hasProperty("vin",org.hamcrest.CoreMatchers.nullValue())))))
				.thenThrow(new ServiceException("Invalid Vehicle ID", "INVALID_VEHICLE"));
		
//		Mockito.when(vehicleService.create(Mockito.any(Vehicle.class))).thenThrow(new ServiceException("Invalid Vehicle ID", "INVALID_VEHICLE"));
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/api/vehicles/").accept(MediaType.APPLICATION_JSON)
				.content(InvalidVehicleJson).contentType(MediaType.APPLICATION_JSON);		
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		MockHttpServletResponse response = result.getResponse();
		assertEquals("Expected code did not match", 400, response.getStatus());
		JSONAssert.assertEquals(expectedJson, response.getContentAsString(), false);
		
	}
	
	


}
