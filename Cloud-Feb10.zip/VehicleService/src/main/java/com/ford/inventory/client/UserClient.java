package com.ford.inventory.client;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.ford.inventory.security.TokenUser;

@FeignClient("user-service")
public interface UserClient {
	
	@GetMapping("/api/user/search/email/{email}")
	TokenUser getUserByEmail(@PathVariable("email") String email);

}
