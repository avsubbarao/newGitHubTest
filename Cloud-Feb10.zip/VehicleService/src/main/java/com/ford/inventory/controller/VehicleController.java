package com.ford.inventory.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ford.inventory.domain.Vehicle;
import com.ford.inventory.dto.ResponseMsg;
import com.ford.inventory.service.VehicleService;

@RestController
@RequestMapping("/api/vehicles")
public class VehicleController {
	
	@Autowired
	private VehicleService vehicleService;
	
	@PostMapping("/")
	public ResponseEntity<?> createVehicle(@RequestBody Vehicle vehicle){
		vehicleService.create(vehicle);
		return new ResponseEntity<ResponseMsg>(new ResponseMsg("VEHICLE_ADDED", "Vehicle successfully added"), HttpStatus.OK);
	}
	
	/*@GetMapping("/{type}")
	public List<Vehicle> getVehicle(@PathVariable String type, @RequestBody Vehicle vehicle) {
		return vehicleService.getAll(type);
		
	}*/

	@GetMapping("/search/type/{type}")
	public List<Vehicle> getVehiclesByType(@PathVariable String type) {
		return vehicleService.getVehiclesByType(type);
		
	}
	
	/*@GetMapping("/{type}")
	public Vehicle getVehicle(@PathVariable String type) {
		return vehicleService.get(type);
		
	}*/
}
