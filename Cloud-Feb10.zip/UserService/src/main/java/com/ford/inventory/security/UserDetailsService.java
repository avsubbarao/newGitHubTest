package com.ford.inventory.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AccountStatusUserDetailsChecker;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.ford.inventory.domain.User;
import com.ford.inventory.repository.UserRepository;

@Service
public class UserDetailsService implements org.springframework.security.core.userdetails.UserDetailsService {

	
	private static final Logger LOGGER = LoggerFactory.getLogger(UserDetailsService.class);
	
	private final AccountStatusUserDetailsChecker detailsChecker = new AccountStatusUserDetailsChecker();

	@Autowired
	private UserRepository userRepository;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		LOGGER.debug("UserName: " + username);
		User user = userRepository.findByEmail(username);
		if(user == null)
				throw new UsernameNotFoundException("Invalid user name");

		org.springframework.security.core.userdetails.User userDetails = new org.springframework.security.core.userdetails.User(
				username, user.getPassword(), user.isEnabled(), true, true, true,
				AuthorityUtils.createAuthorityList(user.getUserTyp()));
		detailsChecker.check(userDetails);
		return userDetails;
	}

}
