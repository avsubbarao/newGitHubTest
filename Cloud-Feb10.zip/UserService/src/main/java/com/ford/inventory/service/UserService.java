package com.ford.inventory.service;

import com.ford.inventory.domain.User;
import com.ford.inventory.security.TokenUser;

public interface UserService {

	String create(User user);
	
	User get(Long id);
	
	TokenUser findByEmail(String email); 
	
}
