package com.ford.inventory.domain;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="user_table")
public class User{

	@Id
	private Long id;
	private String email;
	private String lName;
	private String fName;
	private String phone;
	private String userTyp;
	private String address;
	private String password;
	private boolean enabled;
	
	public User(Long id, String email, String lName, String fName, String phone, String userTyp, String address,
			String password, boolean enabled) {
		super();
		this.id = id;
		this.email = email;
		this.lName = lName;
		this.fName = fName;
		this.phone = phone;
		this.userTyp = userTyp;
		this.address = address;
		this.password = password;
		this.enabled = enabled;
	}

	public User() {
	}

	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public boolean isEnabled() {
		return enabled;
	}


	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getUserTyp() {
		return userTyp;
	}
	public void setUserTyp(String userTyp) {
		this.userTyp = userTyp;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}
	
	
}
