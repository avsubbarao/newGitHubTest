package com.ford.inventory.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.ford.inventory.domain.User;
import com.ford.inventory.repository.UserRepository;
import com.ford.inventory.security.TokenUser;
import com.ford.inventory.service.UserService;

@Service
public class UserServiceImpl implements UserService{

	
	private static final Logger LOGGER = LoggerFactory.getLogger(UserServiceImpl.class);

	
	@Autowired 
	UserRepository userRepository;
	
	@Value("${app.token.expiresMS}") long expiresMillisec;
	
	@Override
	public String create(User user) {
		user.setPassword(encryptPassword(user.getPassword()));
		User saved = userRepository.save(user);
		return saved.getEmail();
	}

	@Override
	public User get(Long id) {
		return userRepository.findOne(id);
	}

	
	private String encryptPassword(String password) {
		return new BCryptPasswordEncoder().encode(password);
		}

	@Override
	public TokenUser findByEmail(String email) {
		LOGGER.debug("in findByEmail with: " + email);
		User user = userRepository.findByEmail(email);
		if (user == null)
			return null;
		TokenUser tokenUser = new TokenUser(user.getId(), user.getEmail(), System.currentTimeMillis() + expiresMillisec,
				user.getUserTyp(), "USER");
		return tokenUser;
		
	}

}
