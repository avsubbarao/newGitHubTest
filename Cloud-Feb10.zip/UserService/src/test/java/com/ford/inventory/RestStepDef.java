package com.ford.inventory;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;

import org.json.JSONException;
import org.skyscreamer.jsonassert.JSONAssert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RestStepDef extends SpringIntegrationTest {
	
	private static String authToken;

	private static final Logger LOGGER = LoggerFactory.getLogger(RestStepDef.class);
	
	@When("^Client requests POST (.*) With JSON data$")
	public void performPostWithJsonDataToURL(String url, String jsonData) throws IOException {
		executePost(url, jsonData, authToken);
	}
	
	@When("^Client requests GET (.*)$")
	public void performGetWithURL(String url) throws IOException {
		executeGet(url, authToken);
	}
	
	@Given("^Web-context is setup$")
	public void setupWebContext() {
		
	}
		
	@Then("^response code should be (\\d+)")
	public void chkResponseCode(int expRespCode) throws IOException {
		HttpStatus actual = latestResponse.getTheResponse().getStatusCode();
		assertThat("Status Code is Incorrect: " + latestResponse.getBody(), actual.value(), is(expRespCode));
	}
	
	@And("^result JSON should be$")
	public void chkResponseJson(String expJson) throws JSONException {
		LOGGER.debug("$$$$$$: latestResponse.getBody(): "+latestResponse.getBody());
		LOGGER.debug("$$$$$$: expJson: "+expJson);
		JSONAssert.assertEquals(expJson, latestResponse.getBody(), false);
	}
	
	@And("^user is logged in with userName '(.*)' and password '(.*)'$")
	public void authenticateUser(String username, String password) throws Exception {
		LOGGER.debug("Username: " + username +", Password: " + password);
		HttpStatus actual = latestResponse.getTheResponse().getStatusCode();
		String userJson = "{" + 
				"\"userName\":\""+ username +"\"," + 
				"\"password\":\""+password+"\""
				+ "}";
		executePost("/api/user/login",userJson);
		HttpHeaders headers = latestResponse.getTheResponse().getHeaders();
		authToken = headers.getFirst(AUTH_HEADER_NAME);
		assertEquals("Response Code not matched", 200, actual.value());
		assertNotNull("Auth Token is null", authToken);
		
	}
	
	
	

}
