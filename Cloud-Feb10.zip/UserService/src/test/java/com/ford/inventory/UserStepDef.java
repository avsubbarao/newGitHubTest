package com.ford.inventory;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import com.ford.inventory.domain.User;
import com.ford.inventory.repository.UserRepository;
import cucumber.api.DataTable;
import cucumber.api.java.en.And;

public class UserStepDef extends SpringIntegrationTest {


	@Autowired
	protected UserRepository userRepository;
	
	@And("^the DB is empty$")
	public void emptyDB() {
		userRepository.deleteAll();		
	}
	
	@And("^the following users exist$")
	public void create(DataTable items) {
		List<User> itemList = items.asList(User.class);
		userRepository.save(itemList);
	}

}
