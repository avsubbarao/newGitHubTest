package com.ford.inventory.controller;



import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.ford.inventory.domain.User;
import com.ford.inventory.service.ServiceException;
import com.ford.inventory.service.UserService;

@RunWith(SpringRunner.class)
@WebMvcTest(value=UserController.class, secure=false)
public class UserControllerTests {
	private static final Logger LOG = LoggerFactory.getLogger(UserControllerTests.class);
	
	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private UserService userService;
	
	@Test
	public void givenValidId_WhenGetUser_ThenReturnJson() throws Exception{
		LOG.debug("In givenValidId_WhenGetUser_ThenReturnJson");
		User user = new User(1l, "rmanoharan6@csc.com", "Manoharan", "Ramesh", "248-997-0200", "Customer", "123, Car Street", "", true);
		String userJson = "{" + 
				"\"id\":1," +
				"\"email\":\"rmanoharan6@csc.com\"," + 
				"\"lName\":\"Manoharan\"," + 
				"\"fName\":\"Ramesh\"," + 
				"\"phone\":\"248-997-0200\"," + 
				"\"userTyp\":\"Customer\"," + 
				"\"address\":\"123, Car Street\"," +
				"\"enabled\":true" +
				"}";
		Mockito.when(userService.get(Mockito.anyLong())).thenReturn(user);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/api/user/1").accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		MockHttpServletResponse response = result.getResponse();
		assertEquals("Expected code did not match", 200, response.getStatus());
		JSONAssert.assertEquals(userJson, response.getContentAsString(), false);
	}
	
	@Test
	public void givenInvalidId_WhenGetUser_ThenReturnJson() throws Exception{
		LOG.debug("In givenInvalidId_WhenGetUser_ThenReturnJson");
		String expectedErrorJson = "{" + 
				"\"code\":\"INVALID_ID\"," + 
				"\"message\":\"Invalid Id\"" + 
				"}";
		Mockito.when(userService.get(Mockito.anyLong())).thenThrow(new ServiceException("Invalid Id","INVALID_ID"));
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/api/user/1").accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		MockHttpServletResponse response = result.getResponse();
		assertEquals("Expected code did not match", 400, response.getStatus());
		JSONAssert.assertEquals(expectedErrorJson, response.getContentAsString(), false);
	}
	
}
